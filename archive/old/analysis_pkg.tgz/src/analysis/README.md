# src/analysis — recomputation of the paper's flood-map and exposure results

| File | Purpose |
|---|---|
| `flood_model.py` | Flood map from satellite-calibrated trigger levels, population exposure, commune aggregation (Python port of the demo) |
| `reproduce_table.py` | Recomputes the exposure-by-stage table and checks every value against the paper (`python -m analysis.reproduce_table` from `src/`) |

Notebook: `notebooks/01_flood_map_and_exposure.ipynb`.

Needs `data/derived/grids_public.npz` (in the repository) and `data/restricted/calib.json` (derived from MRC data;
obtain from the authors after permission from MRC, or rebuild it from your own MRC licence).

Not covered here yet: Sentinel-1 comparison (E3, needs the six SAR flood masks), GHS-POP comparison (E5) and the
forecast-skill tables (E1, E2, E7, which need the MRC-derived forecasts).
