# src/analysis — recomputation of the paper's results (E1–E8)

Run `python -m analysis.reproduce_all` from `src/` (add `--full` for E7 and the Monte Carlo checks, a few minutes).
It recomputes the tables below and compares **every value** with the paper; see "Status" for what matches.

| Module | Experiments |
|---|---|
| `flood_model.py` | Flood map from satellite-calibrated trigger levels, exposure per cell and commune (Table `explev`, E5) |
| `forecast_skill.py` | E1 (RMSE, MAE, bias, NSE, block bootstrap, Diebold–Mariano, alert detection), E2 (M2, M3b, M4), E7 (forecast error → exposure) |
| `sensitivity.py` | E4 (threshold, satellite-frequency, stage, population and DEM uncertainty) and the layer ablation of E8 |
| `population_sources.py` | E5 comparison WorldPop vs GHS-POP R2023A |
| `sar_validation.py` | E3 metrics for an observed flood mask (the six Sentinel-1 masks are not in the repository) |
| `reproduce_table.py`, `reproduce_all.py` | Checks against the paper |

Notebooks: `notebooks/01_flood_map_and_exposure`, `02_forecast_skill`, `03_sensitivity_and_ablation`.

## Status (301 values compared in the default run)

* 268 identical to the paper; 31 close: 24 bootstrap confidence limits (within 1 percentage point; they depend on the
  random stream), the RF CSI of M4 at 15 days (0.593 vs 0.596), and six GHS-POP totals (within 0.02 %).
* 2 differ: E8, "DEM only, flat surface" at 4.70 m gives 1,027,917 people (Spearman 0.827); the paper has 1,058,948
  (0.834). The other seven E8 rows are identical.
* Not covered: **E3** (needs the Sentinel-1 flood masks), **E8 feature-group ablation** (needs retraining M1 on the
  processed data in `data/processed`), **E6** (compares the 3-D demo with a recomputation, a property of the demo).

Inputs: `data/derived/` (open data), `data/mrc_derived/` (derived from MRC data; read its README).
