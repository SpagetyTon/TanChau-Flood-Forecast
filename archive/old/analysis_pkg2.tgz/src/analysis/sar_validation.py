"""Comparison of the flood map with an observed (Sentinel-1) flood mask (E3, paper Sect. 4.4).

The six Sentinel-1 flood masks (2022-2025, Tan Chau stage 2.74-3.75 m) are NOT part of this repository: producing
them needs the Sentinel-1 scenes and the water-detection workflow run on Google Earth Engine. Once a mask is
available on the model grid (boolean array, True = flooded), ``compare`` returns the paper's metrics.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import spearmanr


def compare(model, level: float, sar_mask: np.ndarray, valid: np.ndarray | None = None) -> dict:
    """IoU, F1, precision, recall of the map against a SAR mask on land cells outside permanent water.

    ``valid`` optionally restricts the comparison (e.g. cells with a valid SAR observation).
    """
    _, depth = model.flood(level)
    pred = depth > 0
    land = (model.river == 0) & ~(model.occ >= 90)
    if valid is not None:
        land &= valid
    p, o = pred & land, sar_mask & land
    tp, fp, fn = (p & o).sum(), (p & ~o).sum(), (~p & o).sum()
    return {"IoU": tp / (tp + fp + fn), "F1": 2 * tp / (2 * tp + fp + fn), "precision": tp / (tp + fp),
            "recall": tp / (tp + fn), "predicted_km2": p.sum() * model.grid.cell_km2,
            "observed_km2": o.sum() * model.grid.cell_km2}


def dem_baseline_iou(model, level: float, sar_mask: np.ndarray) -> float:
    """IoU of the DEM-only baseline (tilted water surface, connected to rivers) for the same scene."""
    _, depth = model.flood(level, mode="dem")
    land = (model.river == 0) & ~(model.occ >= 90)
    p, o = (depth > 0) & land, sar_mask & land
    return (p & o).sum() / (p | o).sum()


def commune_rank_correlation(model, level: float, sar_mask: np.ndarray) -> float:
    """Spearman correlation between communes ranked by mapped and by observed flooded land area."""
    _, depth = model.flood(level)
    n = len(model.adm_names) + 1
    land = (model.river == 0) & ~(model.occ >= 90)
    mapped = np.bincount(model.adm[(depth > 0) & land].ravel(), minlength=n)[1:]
    seen = np.bincount(model.adm[sar_mask & land].ravel(), minlength=n)[1:]
    return float(spearmanr(mapped, seen)[0])
